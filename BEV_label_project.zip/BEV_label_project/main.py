import math
import numpy as np
import cv2 as cv
import glob
import json
import sophus as sp


class Lidar:
    pcd_path_list = []

    def __init__(self, pcd_path):
        self.pcd_path_list = glob.glob(pcd_path + "*.pcd")


class Camera:
    name = ""
    K = []
    D = []
    ext_lidar2cam = []
    img_path_list = []

    def __init__(self, name, int_path, ext_path):
        fs_int = cv.FileStorage(int_path, cv.FILE_STORAGE_READ)
        self.name = name
        self.K = fs_int.getNode('intrinsic').mat()
        self.D = fs_int.getNode('distCoeffs').mat()
        fs_ext = cv.FileStorage(ext_path, cv.FILE_STORAGE_READ)
        self.ext_lidar2cam = fs_ext.getNode('Rt').mat()

    def set_img_path(self, img_path):
        self.img_path_list = glob.glob(img_path + "*.jpg")

    def project_lidar2img(self, pt_lidar):
        pt_cam_x = pt_lidar[0] * self.ext_lidar2cam[0][0] + \
                   pt_lidar[1] * self.ext_lidar2cam[0][1] + \
                   pt_lidar[2] * self.ext_lidar2cam[0][2] + self.ext_lidar2cam[0][3]
        pt_cam_y = pt_lidar[0] * self.ext_lidar2cam[1][0] + \
                   pt_lidar[1] * self.ext_lidar2cam[1][1] + \
                   pt_lidar[2] * self.ext_lidar2cam[1][2] + self.ext_lidar2cam[1][3]
        pt_cam_z = pt_lidar[0] * self.ext_lidar2cam[2][0] + \
                   pt_lidar[1] * self.ext_lidar2cam[2][1] + \
                   pt_lidar[2] * self.ext_lidar2cam[2][2] + self.ext_lidar2cam[2][3]

        if abs(math.atan(pt_cam_x / pt_cam_z)) > 60:
            return -1, -1

        if pt_cam_z < 0.2:
            return -1, -1

        x_u = pt_cam_x / pt_cam_z
        y_u = pt_cam_y / pt_cam_z

        r2 = x_u * x_u + y_u * y_u
        r4 = r2 * r2
        r6 = r4 * r2
        a1 = 2 * x_u * y_u
        a2 = r2 + 2 * x_u * x_u
        a3 = r2 + 2 * y_u * y_u
        cdist = 1 + self.D[0] * r2 + self.D[1] * r4 + self.D[4] * r6
        icdist2 = 1. / (1 + self.D[5] * r2 + self.D[6] * r4 + self.D[7] * r6)

        x_d = x_u * cdist * icdist2 + self.D[2] * a1 + self.D[3] * a2
        y_d = y_u * cdist * icdist2 + self.D[2] * a3 + self.D[3] * a1

        x = self.K[0][0] * x_d + self.K[0][2]
        y = self.K[1][1] * y_d + self.K[1][2]
        return x[0], y[0]


def GetBoundingBoxPoints(x, y, z, l, w, h, r_x, r_y, r_z):
    # cos_a = math.cos(r_z)
    # sin_a = math.sin(r_z)
    cos_a = math.cos(r_z - math.pi / 2)
    sin_a = math.sin(r_z - math.pi / 2)
    half_l = l / 2
    half_w = w / 2
    half_h = h / 2
    #
    #    pt0 -- pt1
    #   / |    / |
    # pt2 -- pt3 |
    #  |  |   |  |
    #  | pt4 -- pt5
    #  | /    | /
    # pt6 -- pt7
    #
    pt0 = [cos_a * -half_w - sin_a * -half_l + x,
           sin_a * -half_w + cos_a * -half_l + y,
           z - half_h]
    pt1 = [cos_a * half_w - sin_a * -half_l + x,
           sin_a * half_w + cos_a * -half_l + y,
           z - half_h]
    pt2 = [cos_a * -half_w - sin_a * half_l + x,
           sin_a * -half_w + cos_a * half_l + y,
           z - half_h]
    pt3 = [cos_a * half_w - sin_a * half_l + x,
           sin_a * half_w + cos_a * half_l + y,
           z - half_h]
    pt4 = [cos_a * -half_w - sin_a * -half_l + x,
           sin_a * -half_w + cos_a * -half_l + y,
           z + half_h]
    pt5 = [cos_a * half_w - sin_a * -half_l + x,
           sin_a * half_w + cos_a * -half_l + y,
           z + half_h]
    pt6 = [cos_a * -half_w - sin_a * half_l + x,
           sin_a * -half_w + cos_a * half_l + y,
           z + half_h]
    pt7 = [cos_a * half_w - sin_a * half_l + x,
           sin_a * half_w + cos_a * half_l + y,
           z + half_h]
    return [pt0, pt1, pt2, pt3, pt4, pt5, pt6, pt7]


if __name__ == '__main__':
    front_120 = Camera("front_120",
                       "./calib/intrinsics/front120_.json",
                       "./calib/extrinsics-240119/lidar2cam/lidar_front_120_ext_lccos.json")
    right_front = Camera("right_front",
                         "./calib/intrinsics/right_front.json",
                         "./calib/extrinsics-240119/lidar2cam/lidar_right_front_ext_lccos.json")
    right_back = Camera("right_back",
                        "./calib/intrinsics/right_rear.json",
                        "./calib/extrinsics-240119/lidar2cam/lidar_right_back_ext_lccos.json")
    back = Camera("back",
                  "./calib/intrinsics/drvRear60.json",
                  "./calib/extrinsics-240119/lidar2cam/lidar_back_ext_lccos.json")
    left_back = Camera("left_back",
                       "./calib/intrinsics/left_rear.json",
                       "./calib/extrinsics-240119/lidar2cam/lidar_left_back_ext_lccos.json")
    left_front = Camera("left_front",
                        "./calib/intrinsics/left_front.json",
                        "./calib/extrinsics-240119/lidar2cam/lidar_left_front_ext_lccos.json")
    lidar = Lidar("./data/lidar/")

    camera_list = [front_120, right_front, right_back, back, left_back, left_front]
    for camera in camera_list:
        camera.set_img_path("./data/3d/" + camera.name + "/")

    #  3d label vis
    with open("./label/1693314445.800071.json", "r") as f:
        # 解析json文件
        label = json.load(f)
    for camera in camera_list:
        cam_bounding_box_pts_dict = dict()
        for camera_label in label['camera'][camera.name]:
            annotation = camera_label['annotation']['data']
            # 按照相应格式读取bounding box坐标框
            back = annotation['back']
            front = annotation['front']
            cam_bounding_box_pts_dict[camera_label['id']] = [[back[0]['x'], back[0]['y']],
                                                             [back[1]['x'], back[1]['y']],
                                                             [back[2]['x'], back[2]['y']],
                                                             [back[3]['x'], back[3]['y']],
                                                             [front[0]['x'], front[0]['y']],
                                                             [front[1]['x'], front[1]['y']],
                                                             [front[2]['x'], front[2]['y']],
                                                             [front[3]['x'], front[3]['y']]]

        lidar_bounding_box_pts_dict = dict()
        for lidar_label in label["lidar"]:
            if lidar_label['id'] + "-" + camera.name in cam_bounding_box_pts_dict.keys():
                annotation = lidar_label['annotation']['data']
                position = annotation['position']
                dimension = annotation['dimension']
                rotation = annotation['rotation']
                bounding_box_pts = GetBoundingBoxPoints(position['x'], position['y'], position['z'],
                                                        dimension['l'], dimension['w'], dimension['h'],
                                                        rotation['x'], rotation['y'], rotation['z'])
                lidar_bounding_box_pts_dict[lidar_label['id']] = bounding_box_pts

        img = cv.imread(camera.img_path_list[0])
        for lidar_pts_key in lidar_bounding_box_pts_dict:
            img_pt_list = []
            for lidar_pt in lidar_bounding_box_pts_dict[lidar_pts_key]:
                img_pt = camera.project_lidar2img(lidar_pt)
                img_pt_list.append((int(img_pt[0]), int(img_pt[1])))
            for img_pt in img_pt_list:
                cv.circle(img, img_pt, 2, (255, 0, 0), -1)
            cv.line(img, img_pt_list[0], img_pt_list[1], (0, 0, 255), 1)
            cv.line(img, img_pt_list[1], img_pt_list[3], (0, 0, 255), 1)
            cv.line(img, img_pt_list[2], img_pt_list[3], (0, 0, 255), 1)
            cv.line(img, img_pt_list[0], img_pt_list[2], (0, 0, 255), 1)
            cv.line(img, img_pt_list[4], img_pt_list[5], (0, 0, 255), 1)
            cv.line(img, img_pt_list[5], img_pt_list[7], (0, 0, 255), 1)
            cv.line(img, img_pt_list[6], img_pt_list[7], (0, 0, 255), 1)
            cv.line(img, img_pt_list[4], img_pt_list[6], (0, 0, 255), 1)
            cv.line(img, img_pt_list[0], img_pt_list[4], (0, 0, 255), 1)
            cv.line(img, img_pt_list[1], img_pt_list[5], (0, 0, 255), 1)
            cv.line(img, img_pt_list[2], img_pt_list[6], (0, 0, 255), 1)
            cv.line(img, img_pt_list[3], img_pt_list[7], (0, 0, 255), 1)

        cv.imshow(camera.name, img)

    for camera in camera_list:
        camera.set_img_path("./data/4d/" + camera.name + "/")
    # time_diff = [0.0, 0.125, 0.337, 0.5, 0.667, 0.87]
    time_diff = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

    # 4d label vis
    T_0 = np.array([[0.985632906, 0.168814604, -0.002700094, 13.37262887],
                    [-0.168780175, 0.985586809, 0.009334901, -0.214535452],
                    [0.004234886, -0.008747009, 0.999862378, -0.067992596],
                    [0, 0, 0, 1]])
    T_1 = np.array([[0.983424896, 0.181232798, -0.00257007, 13.80261127],
                    [-0.181196423, 0.983374274, 0.009879223, -0.291069531],
                    [0.004315394, -0.009251906, 0.999854375, -0.074572827],
                    [0, 0, 0, 1]])
    T_delta = np.dot(np.linalg.inv(T_0), T_1)
    R_delta = T_delta[0:3, 0:3]
    R_delta = sp.to_orthogonal(R_delta)
    t_delta = T_delta[0:3, 3]
    T_delta_SE3 = sp.SE3(R_delta, t_delta)
    with open("./label/4d/annos/1693314445.0/annos.json", "r") as f:
        label = json.load(f)
    annos = label['element_annos'][0]['rawdata_annos'][0]['objects']
    for idx, camera in enumerate(camera_list):
        img = cv.imread(camera.img_path_list[0])
        T_delta_inter_se3 = time_diff[idx] * T_delta_SE3.log()
        print(T_delta_inter_se3)
        T_delta_inter_SE3 = sp.SE3.exp(T_delta_inter_se3).matrix()
        ext = np.dot(T_0, T_delta_inter_SE3)
        print(ext)
        camera.ext_lidar2cam = np.dot(camera.ext_lidar2cam, np.linalg.inv(ext))

        for anno in annos:
            data_list = anno['label']['widget']['data']
            img_pt_list = []
            for data_idx in range(0, len(data_list), 3):
                img_pt = camera.project_lidar2img((data_list[data_idx], data_list[data_idx + 1], data_list[data_idx + 2]))
                if img_pt[0] == -1 or img_pt[0] <= 0 or img_pt[0] > img.shape[1] or img_pt[1] <= 0 or img_pt[1] > img.shape[0]:
                    continue
                img_pt_list.append((int(img_pt[0]), int(img_pt[1])))
                cv.circle(img, (int(img_pt[0]), int(img_pt[1])), 2, (255, 0, 0), -1)
            for pt_idx in range(0, len(img_pt_list) - 1):
                cv.line(img, img_pt_list[pt_idx], img_pt_list[pt_idx + 1], (0, 0, 255), 1)
        cv.imshow(camera.name, img)
        cv.waitKey(0)