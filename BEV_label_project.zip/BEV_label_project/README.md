# yh_BEV_label_project

将kaiwang的3D/4D标注信息投影到图像中